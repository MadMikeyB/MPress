<?php

namespace Doctrine\Tests\Common\Proxy;

/**
 * Test asset class
 */
class CallableTypeHintClass
{
    /**
     * @param callable $foo
     */
    public function call(callable $foo)
    {
    }
}
