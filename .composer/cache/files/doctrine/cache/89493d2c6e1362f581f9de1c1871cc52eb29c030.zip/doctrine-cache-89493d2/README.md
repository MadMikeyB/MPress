# Doctrine Cache

Cache component extracted from the Doctrine Common project.

## Changelog

### v1.1

* Added support for MongoDB as Cache Provider
