<?php namespace Illuminate\Database\Eloquent;

class ModelNotFoundException extends \RuntimeException {}