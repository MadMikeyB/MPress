<?php namespace Illuminate\Routing\Controllers;

class Before extends Filter {}