CHANGELOG
=========

2.3.0
-----

 * added the component
